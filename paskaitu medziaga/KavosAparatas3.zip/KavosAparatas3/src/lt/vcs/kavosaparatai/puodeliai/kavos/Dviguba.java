package lt.vcs.kavosaparatai.puodeliai.kavos;

import lt.vcs.kavosaparatai.puodeliai.KavosPuodelis;

public class Dviguba extends KavosPuodelis{

    public Dviguba() {
        super("dviguba", 8, 8, 8);
    }

}
