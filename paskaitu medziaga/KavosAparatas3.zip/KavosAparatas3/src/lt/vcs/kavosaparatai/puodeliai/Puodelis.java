package lt.vcs.kavosaparatai.puodeliai;

public class Puodelis {
    
    final static int MAX_TALPA = 5;

}
