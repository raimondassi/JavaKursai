package lt.vcs.kavosaparatai.puodeliai.kavos;

import lt.vcs.kavosaparatai.puodeliai.KavosPuodelis;

public class Normali extends KavosPuodelis{

    public Normali() {
        super("normali", 4, 4, 4);
    }

}
