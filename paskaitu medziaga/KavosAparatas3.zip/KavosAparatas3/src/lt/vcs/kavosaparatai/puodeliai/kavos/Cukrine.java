package lt.vcs.kavosaparatai.puodeliai.kavos;

import lt.vcs.kavosaparatai.puodeliai.KavosPuodelis;

public class Cukrine extends KavosPuodelis{

    public Cukrine() {
        super("cukrine", 8, 4, 4);
    }

}
